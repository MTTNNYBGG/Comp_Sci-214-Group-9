import sys
import picture as p
from picture import Picture
import stddraw, math, random

# Defining the life cycle of objects
cycle_fly = [1, 1, 'FLY']
cycle_bee = [1, 1, 'BEE']
cycle_shooter = [1, 1, 'SHOOTER']

cycle_dict = {
    'FLY': cycle_fly,
    'BEE': cycle_bee,
    'SHOOTER': cycle_shooter
}

def law_con_mech(v1, v2, m1, m2):
    v2c = m1 * v1 - m2 * v2
    v1c = m2 * v2 - m1 * v1
    return [v1 + v1c / m1, v2 + v2c / m2]

def get_slope(x1,y1,x2,y2):
    return (y2-y1)/(x2-x1)

def slope2rad(slope):
    return math.atan(slope)

class GameObject:
    def __init__(self, x_location, y_location, image_filename, x_size, y_size, x_velocity, y_velocity, object_id, life, typeobj):
        self.x_location = x_location
        self.y_location = y_location
        self.image_filename = image_filename
        self.x_size = x_size
        self.y_size = y_size
        self.x_velocity = x_velocity
        self.y_velocity = y_velocity
        self.object_id = object_id
        self.life = life
        self.typeobj = typeobj
    
    def getv_x(self, x_change=0):
        self.x_velocity += x_change
        return self.x_velocity
    
    def getv_y(self, y_change=0):
        self.y_velocity+=y_change
        return self.y_velocity


    def get_x(self, x_change=0):
        self.x_location+=x_change
        return self.x_location
    
    def get_y(self, y_change=0):
        self.y_location+=y_change
        return self.y_location

    def set_velocity(self, magnitude, teetah):
        self.x_velocity = magnitude*math.cos(teetah)
        self.y_velocity = magnitude*math.sin(teetah)
        



    def get_dimensions(self):
        pic = Picture(self.image_filename)
        return [pic.width(), pic.height()]

    def draw_object(self):
        pic = Picture(self.image_filename)
        stddraw.picture(pic, self.x_location, self.y_location, self.x_size, self.y_size)

    def get_speed(self):
        return (self.x_velocity**2 + self.y_velocity**2) ** 0.5

def report(obj, objecter_check):
    to_remove = []
    for other in objecter_check:
        if obj.object_id != other.object_id:
            if obj.typeobj == 'FLY' and other.typeobj == 'BULLET':
                if obj.x_location == other.x_location and obj.y_location == other.y_location:
                    vx = law_con_mech(obj.x_velocity, other.x_velocity, 1, 1)
                    obj.x_velocity, other.x_velocity = vx[0], vx[1]
                    obj.x_location += vx[0]
                    other.x_location += vx[1]

                    vy = law_con_mech(obj.y_velocity, other.y_velocity, 1, 1)
                    obj.y_velocity, other.y_velocity = vy[0], vy[1]
                    obj.y_location += vy[0]
                    other.y_location += vy[1]

                    obj.life -= other.life
                    if obj.life <= 0:
                        to_remove.append(obj)
    return to_remove

def main():
    fly = 'Fly.png'
    tank = 'Tank.png'
    background = 'Background.png'

    stddraw.setCanvasSize(750, 650)
    stddraw.setXscale(0, 100)
    stddraw.setYscale(0, 100)

    count_object = 120
    thelist_object = []

    
    for i in range(count_object - 1):
        new_obj = GameObject(100 * random.random(), 75+50 * random.random(), fly, 10, 10, 2, 2, i + 1, 10, 'FLY')
        thelist_object.append(new_obj)

    player_x = 5+90 * random.random()
    player_y = 5
    player = GameObject(player_x,player_y, tank, 10, 10, 0, 0, count_object, 10, 'PLAYER')
    
    mypic = Picture(background)


    while True:#1==1 meaning a infinite loop
        stddraw.picture(mypic, 50, 50,100,100)
        for obj in thelist_object:
            slope = get_slope(obj.get_x(),obj.get_y(), player.get_x(), player.get_y())
            angle = slope2rad(slope)
            if random.random()>0.8:#The chance of going of perpendicular path is 0.7
                angle = angle+random.randint(0,3)*math.pi/2
            obj.set_velocity(obj.get_speed(), angle)
            
            if (5<=obj.get_x()+obj.getv_x()<95):
                #inserted v_x and v_y to force distance increase.i
                obj.get_x(obj.getv_x())

            if (5<=obj.get_y()+obj.getv_y()<95):
                obj.get_y(obj.getv_y())



            if (5<=obj.get_x()<95) and (5<=obj.get_y()<95):
                #inserted v_x and v_y to force distance increase.i
                obj.draw_object()

        if stddraw.hasNextKeyTyped():        
            key = stddraw.nextKeyTyped()
            x,y = 0,0
      	   
            if key == "a":#Not using Left, Right, Up, Down because they aren't being registered
                x = -2
            elif key == "d":
                x = 2
            elif key == "w":
                y = 2
            elif key == "s":
                y = -2
            elif key=="q":
                break
            if 5<=player.get_x()+x<95:
                player.get_x(x)
            if 5<=player.get_y()+y<95:
                player.get_y(y)



        player.draw_object()
 
        stddraw.show(10)

if __name__ == '__main__':
    main()
